﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace platformerap
{
    public class Tiles
    {
        public Texture2D texture;

        public Rectangle Rectangle { get; set;}
        public static ContentManager Content { get; set; }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, Rectangle, Color.White);
        }
    }

    public class WaterTiles : Tiles
    {
        public WaterTiles(int i, Rectangle newRectangle)
        {
            texture = Content.Load<Texture2D>(i.ToString());
            Rectangle = newRectangle;
        }
    }

    public class DoorTiles : Tiles
    {
        public bool spawned { get; set; }
        public DoorTiles(int i, Rectangle newRectangle)
        {
            texture = Content.Load<Texture2D>(i.ToString());
            Rectangle = newRectangle;
            spawned = true;
        }
    }

    public class ExitTiles : Tiles
    {
        public bool spawned { get; set; }
        public ExitTiles(int i, Rectangle newRectangle)
        {
            texture = Content.Load<Texture2D>(i.ToString());
            Rectangle = newRectangle;
        }
    }

    public class CollisionTiles : Tiles
    {
        public CollisionTiles(int i, Rectangle newRectangle)
        {
            texture = Content.Load<Texture2D>(i.ToString());
            Rectangle = newRectangle;
        }
    }

    public class MagicTiles : Tiles
    {
        private bool Visible { get; set; }
        public float delay = 2f;

        public MagicTiles(int i, Rectangle newRectangle, bool newVisible)
        {
            texture = Content.Load<Texture2D>(i.ToString());
            Rectangle = newRectangle;
            Visible = newVisible;
        }

        public void Update(GameTime gameTime)
        {
            
            float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;
            delay -= dt;

            if (delay < 0f) {
                System.Diagnostics.Debug.WriteLine(delay);
                this.Visible = false;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.S))
            {
                delay = 2f;
                this.Visible = true;
            }
                
        }

        new public void Draw(SpriteBatch spriteBatch)
        {
            if (this.Visible) spriteBatch.Draw(texture, Rectangle, Color.White);
        }
    }

    public class MovingTiles : Tiles
    {
        private bool Horizontally { get; set; }
        private bool Vertically { get; set; }
        private int Velocity { get; set; }
        int leftBoundry, rightBoundry, topBoundry, bottomBoundry, x, y;
        bool goingRight = true, goingUp = true;


        public MovingTiles(int i, Rectangle newRectangle, int newVelocity, bool newVertically, bool newHorizontally)
        {
            texture = Content.Load<Texture2D>(i.ToString());
            Rectangle = newRectangle;
            Vertically = newVertically;
            Horizontally = newHorizontally;
            Velocity = newVelocity;

            leftBoundry = Rectangle.X;
            rightBoundry = Rectangle.X + Rectangle.Width * 3;

            topBoundry = Rectangle.Y - Rectangle.Height * 3;
            bottomBoundry = Rectangle.Y;

            x = Rectangle.X;
            y = Rectangle.Y;
        }

        public void Update(GameTime gameTime)
        {
            float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (Horizontally)
            {
                if (Rectangle.X < rightBoundry && goingRight)
                {
                    x = Rectangle.X + (int)(Velocity * dt);
                }
                else if (Rectangle.X > leftBoundry)
                {
                    goingRight = false;
                    x = Rectangle.X - (int)(Velocity * dt);
                }
                else
                {
                    goingRight = true;
                }
            }

            if (Vertically)
            {
                if (Rectangle.Y > topBoundry && goingUp)
                {
                    y = Rectangle.Y - (int)(Velocity * dt);
                }
                else if (Rectangle.Y < bottomBoundry)
                {
                    goingUp = false;
                    y = Rectangle.Y + (int)(Velocity * dt);
                }
                else
                {
                    goingUp = true;
                }
            }

            Rectangle = new Rectangle(x, y, Rectangle.Width, Rectangle.Height);
        }
    }
}
