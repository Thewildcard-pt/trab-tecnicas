﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace platformerap
{
    public class Map
    {
        // Private variables
        private List<CollisionTiles> collisionTiles = new List<CollisionTiles>();
        private List<WaterTiles> waterTiles = new List<WaterTiles>();
        private List<MovingTiles> movingTiles = new List<MovingTiles>();
        private List<MagicTiles> magicTiles = new List<MagicTiles>();
        private List<DoorTiles> doorTiles = new List<DoorTiles>();
        private List<ExitTiles> exitTiles = new List<ExitTiles>();

        //public access methods
        public List<CollisionTiles> CollisionTiles
        {
            get { return collisionTiles; }
        }
        public List<WaterTiles> WaterTiles
        {
            get { return waterTiles; }
        }
        public List<MovingTiles> MovingTiles
        {
            get { return movingTiles; }
        }
        public List<MagicTiles> MagicTiles
        {
            get { return magicTiles; }
        } 
        public List<DoorTiles> DoorTiles
        {
            get { return doorTiles; }
        }

        public List<ExitTiles> ExitTiles
        {
            get { return exitTiles; }
        }

        public int Width { get; set; }
        public int Height { get; set; }

        public void Generate(int[,] map, int size)
        {
            for (int x = 0; x < map.GetLength(1); x++)
                for (int y = 0; y < map.GetLength(0); y++)
                {
                    int number = map[y, x];

                    if (number > 0 && number != 13 && number != 14 && number != 15 && number != 17 && number != 18 && number !=19)
                        collisionTiles.Add(new CollisionTiles(number, new Rectangle(x * size, y * size, size, size)));
                    else if (number == 13 || number == 14 || number == 15)
                        movingTiles.Add(new MovingTiles(number, new Rectangle(x * size, y * size, size, size), 120, false, true));
                    else if (number == 17 || number == 18)
                        waterTiles.Add(new WaterTiles(number, new Rectangle(x * size, y * size, size, size)));
                    else if (number == 19)
                        doorTiles.Add(new DoorTiles(number, new Rectangle(x * size, y * size, size, size)));
                    else if (number == 20)
                        ExitTiles.Add(new ExitTiles(number, new Rectangle(x * size, y * size, size, size)));
                    Width = (x + 1) * size;
                    Height = (y + 1) * size;
                }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (CollisionTiles tile in CollisionTiles)
                tile.Draw(spriteBatch);
            foreach (MovingTiles tile in MovingTiles)
                tile.Draw(spriteBatch);
            foreach (WaterTiles tile in WaterTiles)
                tile.Draw(spriteBatch);
            foreach (DoorTiles tile in DoorTiles)
                tile.Draw(spriteBatch);
            foreach (ExitTiles tile in ExitTiles)
                tile.Draw(spriteBatch);
        }
    }
}
