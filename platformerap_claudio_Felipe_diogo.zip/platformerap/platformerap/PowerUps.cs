﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace platformerap
{
    class PowerUps
    {
            private Player player { get; set; }
            private bool unlock1;
       public PowerUps(Player jog)
        {
            this.player = jog;
        }
    }
}
